namespace RaceDay.Web.Models;

// Client-side copies of the API's response shapes (see Part3/ApiAdditions for the matching API code).
public class UserDto
{
    public int UserId { get; set; }
    public string Name { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    public string? ProfilePictureUrl { get; set; }
}

public class EventDto
{
    public int EventId { get; set; }
    public int OrganiserId { get; set; }
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Location { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string EventType { get; set; } = "";
    public decimal DistanceKm { get; set; }
    public string? BannerUrl { get; set; }
}

public class CategoryDto
{
    public int CategoryId { get; set; }
    public int EventId { get; set; }
    public string Name { get; set; } = "";
    public decimal DistanceKm { get; set; }
    public decimal Price { get; set; }
}

public class DashboardItemDto
{
    public int EventId { get; set; }
    public string Name { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string Location { get; set; } = "";
    public int EnrolmentCount { get; set; }
}

public class EntrantDto
{
    public int EnrolmentId { get; set; }
    public string ParticipantName { get; set; } = "";
    public string ParticipantEmail { get; set; } = "";
    public string CategoryName { get; set; } = "";
    public string Status { get; set; } = "Pending";
    public bool HasResult { get; set; }
    public TimeSpan? FinishTime { get; set; }
    public int? Position { get; set; }
}

public class MyEnrolmentDto
{
    public int EnrolmentId { get; set; }
    public int EventId { get; set; }
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = "";
    public string Status { get; set; } = "Pending";
}

public class MyResultDto
{
    public string EventName { get; set; } = "";
    public DateTime EventDate { get; set; }
    public string CategoryName { get; set; } = "";
    public TimeSpan FinishTime { get; set; }
    public int Position { get; set; }
    public int TotalFinishers { get; set; }
}
