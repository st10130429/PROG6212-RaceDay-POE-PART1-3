using System.ComponentModel.DataAnnotations;

namespace RaceDay.Web.Models;

public class LoginVm
{
    [Required(ErrorMessage = "Email is required."), EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = "";
    [Required(ErrorMessage = "Password is required.")]
    public string Password { get; set; } = "";
}

public class RegisterVm
{
    [Required(ErrorMessage = "Name is required."), StringLength(100)]
    public string Name { get; set; } = "";
    [Required(ErrorMessage = "Email is required."), EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = "";
    [Required(ErrorMessage = "Password is required."), MinLength(6, ErrorMessage = "Password must be at least 6 characters.")]
    public string Password { get; set; } = "";
    [Required(ErrorMessage = "Please confirm your password."), Compare(nameof(Password), ErrorMessage = "Passwords do not match.")]
    public string ConfirmPassword { get; set; } = "";
    [Required(ErrorMessage = "Choose a role.")]
    public string Role { get; set; } = "Participant";
}

public class EventFormVm
{
    public int EventId { get; set; }
    [Required(ErrorMessage = "Name is required."), StringLength(150)]
    public string Name { get; set; } = "";
    [StringLength(2000)]
    public string Description { get; set; } = "";
    [Required(ErrorMessage = "Location is required.")]
    public string Location { get; set; } = "";
    [Required(ErrorMessage = "Date is required."), DataType(DataType.DateTime)]
    public DateTime EventDate { get; set; } = DateTime.Today.AddMonths(1);
    [Required(ErrorMessage = "Event type is required.")]
    public string EventType { get; set; } = "Running";
    [Range(0.1, 1000, ErrorMessage = "Distance must be between 0.1 and 1000 km.")]
    public decimal DistanceKm { get; set; } = 10;
    public string? ExistingBannerUrl { get; set; }
    public IFormFile? Banner { get; set; }
}

public class CategoryFormVm
{
    [Required(ErrorMessage = "Category name is required.")]
    public string Name { get; set; } = "";
    [Range(0, 1000, ErrorMessage = "Distance must be 0-1000 km.")]
    public decimal DistanceKm { get; set; }
    [Range(0, 100000, ErrorMessage = "Price must be 0-100000.")]
    public decimal Price { get; set; }
}

public class ProfileVm
{
    [Required(ErrorMessage = "Name is required.")]
    public string Name { get; set; } = "";
    [Required(ErrorMessage = "Email is required."), EmailAddress(ErrorMessage = "Enter a valid email address.")]
    public string Email { get; set; } = "";
    public string? ProfilePictureUrl { get; set; }
    public IFormFile? Picture { get; set; }
}

public class EventDetailsVm
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
}

public class EventFilterVm
{
    public string? Search { get; set; }
    public string? EventType { get; set; }
    public DateTime? From { get; set; }
    public List<EventDto> Events { get; set; } = new();
}

public class ResultsEntryVm
{
    public EventDto Event { get; set; } = new();
    public List<EntrantDto> Entrants { get; set; } = new();
}

public class CategoriesVm
{
    public EventDto Event { get; set; } = new();
    public List<CategoryDto> Categories { get; set; } = new();
    public CategoryFormVm NewCategory { get; set; } = new();
}
