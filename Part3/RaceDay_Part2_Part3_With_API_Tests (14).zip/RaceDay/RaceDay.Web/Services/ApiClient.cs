using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using Microsoft.AspNetCore.Http;

namespace RaceDay.Web.Services;

/// <summary>Result of an API call. Controllers show Error to the user - never raw exceptions.</summary>
public class ApiResult<T>
{
    public bool Ok { get; init; }
    public T? Data { get; init; }
    public int Status { get; init; }
    public string Error { get; init; } = "";
}

/// <summary>
/// The ONLY way the MVC app gets or changes data: every call goes to the Part 2 API.
/// The API authenticates with a server-side session cookie ("RaceDay.Session"). On login we
/// capture that cookie and keep it in the MVC session, then attach it to every later call
/// made on behalf of that user.
/// </summary>
public class ApiClient
{
    public const string ApiCookieKey = "ApiCookie";
    private const string ApiCookieName = "RaceDay.Session";

    private readonly HttpClient _http;
    private readonly IHttpContextAccessor _ctx;
    private readonly ILogger<ApiClient> _log;

    public ApiClient(HttpClient http, IHttpContextAccessor ctx, ILogger<ApiClient> log)
    {
        _http = http; _ctx = ctx; _log = log;
    }

    public Task<ApiResult<T>> GetAsync<T>(string url) => SendAsync<T>(HttpMethod.Get, url, null);
    public Task<ApiResult<T>> PostAsync<T>(string url, object? body = null) => SendAsync<T>(HttpMethod.Post, url, body is null ? null : JsonContent.Create(body));
    public Task<ApiResult<T>> PutAsync<T>(string url, object? body = null) => SendAsync<T>(HttpMethod.Put, url, body is null ? null : JsonContent.Create(body));
    public Task<ApiResult<bool>> DeleteAsync(string url) => SendAsync<bool>(HttpMethod.Delete, url, null);

    /// <summary>Uploads one image as multipart/form-data (field name "file").</summary>
    public async Task<ApiResult<T>> UploadAsync<T>(string url, IFormFile file)
    {
        using var content = new MultipartFormDataContent();
        await using var stream = file.OpenReadStream();
        var part = new StreamContent(stream);
        part.Headers.ContentType = new MediaTypeHeaderValue(file.ContentType);
        content.Add(part, "file", Path.GetFileName(file.FileName));
        return await SendAsync<T>(HttpMethod.Post, url, content);
    }

    /// <summary>Logs in and keeps the API's session cookie in the MVC session.</summary>
    public async Task<ApiResult<T>> LoginAsync<T>(object credentials)
    {
        var req = new HttpRequestMessage(HttpMethod.Post, "api/auth/login") { Content = JsonContent.Create(credentials) };
        try
        {
            using var resp = await _http.SendAsync(req);
            if (resp.IsSuccessStatusCode && resp.Headers.TryGetValues("Set-Cookie", out var cookies))
            {
                var raw = cookies.FirstOrDefault(c => c.StartsWith(ApiCookieName + "="));
                if (raw is not null)
                {
                    var pair = raw.Split(';')[0]; // "RaceDay.Session=<value>"
                    _ctx.HttpContext!.Session.SetString(ApiCookieKey, pair);
                    _log.LogInformation("API session cookie captured for login");
                }
            }
            return await ToResultAsync<T>(resp);
        }
        catch (Exception ex) { return Fail<T>(ex); }
    }

    private async Task<ApiResult<T>> SendAsync<T>(HttpMethod method, string url, HttpContent? content)
    {
        using var req = new HttpRequestMessage(method, url) { Content = content };
        var cookie = _ctx.HttpContext?.Session.GetString(ApiCookieKey);
        if (!string.IsNullOrEmpty(cookie)) req.Headers.Add("Cookie", cookie);

        try
        {
            _log.LogInformation("API {Method} {Url}", method, url);
            using var resp = await _http.SendAsync(req);
            return await ToResultAsync<T>(resp);
        }
        catch (Exception ex) { return Fail<T>(ex); }
    }

    private async Task<ApiResult<T>> ToResultAsync<T>(HttpResponseMessage resp)
    {
        var status = (int)resp.StatusCode;
        if (resp.IsSuccessStatusCode)
        {
            T? data = default;
            if (typeof(T) == typeof(bool)) data = (T)(object)true;
            else if (resp.StatusCode != HttpStatusCode.NoContent && resp.Content.Headers.ContentLength != 0)
            {
                try { data = await resp.Content.ReadFromJsonAsync<T>(); }
                catch (Exception ex) { _log.LogWarning(ex, "Could not parse API response"); }
            }
            return new ApiResult<T> { Ok = true, Data = data, Status = status };
        }

        _log.LogWarning("API returned {Status}", status);
        return new ApiResult<T> { Ok = false, Status = status, Error = FriendlyMessage(status) };
    }

    private ApiResult<T> Fail<T>(Exception ex)
    {
        _log.LogError(ex, "API call failed");
        return new ApiResult<T> { Ok = false, Status = 0, Error = "We couldn't reach the RaceDay service. Please try again in a moment." };
    }

    /// <summary>Maps HTTP status codes to messages that are safe to show on screen.</summary>
    public static string FriendlyMessage(int status) => status switch
    {
        400 => "Some of the information entered isn't valid. Please check and try again.",
        401 => "Incorrect email or password, or your session has expired. Please log in again.",
        403 => "You don't have permission to do that.",
        404 => "We couldn't find what you were looking for.",
        409 => "That already exists (for example, you're already enrolled or the email is taken).",
        _ => "Something went wrong on our side. Please try again."
    };
}
